<br />
<p align="center">
  <h3 align="center">Fc1 Connector</h3>
</p>

## Prerequisites

    In order to use this connector, you should dispose of a Finalcad Api Key

## Triggers

    When a form is created or updated
    When an observation is created or updated
    When a document is created

## Actions

    Read a form detail
    Read an observation detail
    Read a project informations
    Read current user informations
